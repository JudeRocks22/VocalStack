# VocalStack

A vocal multi-effect plugin (VST3, plus AU on macOS) built with JUCE + CMake.
Fixed signal chain with a knob for every control and a power switch per module:

Pitch correction → EQ → De-esser → Compressor → Saturation → Doubler → Delay → Reverb → Output

| Module | Controls |
|---|---|
| Pitch | Key, Scale (Chromatic/Major/Minor), Speed (ms), Amount (%) |
| EQ | Low cut, Body (250 Hz), Presence (3.5 kHz), Air (10 kHz shelf) |
| De-ess | Frequency, Threshold |
| Compressor | Threshold, Ratio, Attack, Release, Makeup |
| Saturation | Drive, Mix |
| Doubler | Rate, Depth, Mix |
| Delay | Time, Feedback, Tone, Mix |
| Reverb | Size, Damping, Mix |
| Output | Level |

Defaults: EQ, De-ess and Compressor on; everything else off.

## Build (Windows, Visual Studio 2022 or Ninja)

```
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

JUCE 8.0.4 is downloaded automatically on first configure. The VST3 ends up in
`build/VocalStack_artefacts/Release/VST3/VocalStack.vst3`.

## Installer (.exe)

Install [Inno Setup 6](https://jrsoftware.org/isinfo.php), then:

```
iscc installer\VocalStack.iss
```

This produces `installer\Output\VocalStack-Setup.exe`, which installs the plugin to
`C:\Program Files\Common Files\VST3`.

## Notes

- Pitch correction reports ~15 ms of latency (always, even when bypassed, so the track stays aligned).
- The pitch shifter is a simple dual-tap design: good for light-to-moderate correction and
  the classic hard-tuned effect at fast speeds, but not studio-grade on big jumps or breathy parts.
- Saturation is not oversampled yet; high drive can alias.
